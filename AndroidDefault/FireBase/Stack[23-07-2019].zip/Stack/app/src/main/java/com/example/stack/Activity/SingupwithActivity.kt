package com.example.stack.Activity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import com.example.stack.Applications
import com.example.stack.R

class SingupwithActivity : AppCompatActivity() {
    private lateinit var useEmail: Button
    private lateinit var backLogin: TextView
    //View(XML) connectivity ...!
    fun veiwConnectivity(){
        useEmail = findViewById(R.id.btn_email)
        backLogin = findViewById(R.id.tv_back_login)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_singupwith)
        veiwConnectivity()
        if(Applications.isLogin == true){
            //User is already login(Not need to Authenticated) ...!
            val intentToMain = Intent(this, MainActivity::class.java)
            startActivity(intentToMain)
        }else{


            useEmail.setOnClickListener {
                val intentToSingup = Intent(this, SingupActivity::class.java)
                startActivity(intentToSingup)
            }

            backLogin.setOnClickListener {
                val intentToSingin = Intent(this, SinginActivity::class.java)
                startActivity(intentToSingin)
            }
        }
    }
}
