package com.example.stack

import android.app.Application

open class Applications : Application() {
    companion object{
        val isLogin: Boolean = false
    }
}